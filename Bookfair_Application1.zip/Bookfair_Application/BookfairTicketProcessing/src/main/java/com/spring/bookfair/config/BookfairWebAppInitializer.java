package com.spring.bookfair.config;

import org.springframework.web.filter.FormContentFilter;
import org.springframework.web.filter.ForwardedHeaderFilter;
import org.springframework.web.filter.HiddenHttpMethodFilter;
import org.springframework.web.filter.ShallowEtagHeaderFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
import org.h2.server.web.WebServlet;
import jakarta.servlet.Filter;
import jakarta.servlet.MultipartConfigElement;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRegistration;
import jakarta.servlet.ServletRegistration.Dynamic;

public class BookfairWebAppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {
	
	
	
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return null; // Root application context configurations (e.g., Services, Repositories)
	}
	
	

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class<?>[] { BookfairWebMvcConfig.class}; // Web-specific configurations
	}

	@Override
	protected String[] getServletMappings() {
		return new String[] { "/app/*" }; // Direct all requests to DispatcherServlet
	}

	@Override
	protected void customizeRegistration(ServletRegistration.Dynamic registration) {

		MultipartConfigElement config = new MultipartConfigElement(
				"C:\\Users\\PARAMITA SAHA\\OneDrive\\Desktop\\Softwares\\Spring_Workspace\\FirstSpringMVC\\tmp1", 905,
				10000, 100);

		System.out.println(config.getLocation() + ":" + config.getMaxFileSize() + ":" + config.getMaxRequestSize() + ":"
				+ config.getFileSizeThreshold());
		// Optionally also set maxFileSize, maxRequestSize, fileSizeThreshold
		registration.setMultipartConfig(config);
		registration.setInitParameter("enableLoggingRequestDetails", "true");

	}

	@Override
	protected Filter[] getServletFilters() {

		ShallowEtagHeaderFilter ETagFilter = new ShallowEtagHeaderFilter();

		ETagFilter.setWriteWeakETag(true);
		return new Filter[] { new FormContentFilter(), new ForwardedHeaderFilter(true)

				, ETagFilter };// Since we have used ForwardedHeaderFilter , request.getRemoteHost() methods
								// will always
								// send the correct client Host address instead of sending proxy addresses.All
								// X-Forwarded
								// addresses will be used to reflect the client host details or original request
								// details.
	}

}
