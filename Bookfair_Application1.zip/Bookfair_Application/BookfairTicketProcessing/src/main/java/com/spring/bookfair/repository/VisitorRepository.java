package com.spring.bookfair.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.bookfair.domain.Visitor;

@Repository
public interface VisitorRepository extends JpaRepository<Visitor,String>{

}
