package com.spring.bookfair.controller;

import java.nio.charset.StandardCharsets;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.Local;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.spring.bookfair.domain.Visitor;
import com.spring.bookfair.service.BookfairService;
import com.spring.bookfair.service.VisitorService;

/*
 * BookfairController is invoked to handle request purchase tickets online.
 * 
 * 
 */




@Controller
@RequestMapping("/booking")
@SessionAttributes("visitor")
public class BookfairController {
	
	@Autowired
	MessageSource config;
	
	@Autowired
	BookfairService service;
	
	@Autowired
	VisitorService visitorService;
	
	
	@ModelAttribute("visitor")
	public Visitor getVisitor(Locale locale) {
		
		System.out.println("Locale : "+locale);
		
			
		Visitor visitor = new Visitor();
		
		visitor.setId(config.getMessage("id",null, locale));
		visitor.setFname(config.getMessage("fname",null, locale));
		visitor.setLname(config.getMessage("lname",null, locale));
		visitor.setAge(Integer.parseInt(config.getMessage("age",null, locale)));
		visitor.setTicketno(config.getMessage("ticketno",null, locale));
		
		
		visitorService.createTable();
		
		
		return visitor;
		
	}
	
	
	
	
	@GetMapping( value = "/tickets" , version = "1.0")
	public String getTicket(@ModelAttribute(binding = false,name = "visitor") Visitor visitor , Locale locale) {
		
		System.out.println("Locale in /tickets : "+locale);

		
		System.out.println("visitor : "+visitor.getId()+" : "+ visitor.getFname()+ " : "+visitor.getLname()+" : "+visitor.getAge()+" : "+visitor.getTicketno());
		
		
		return "step1";
			
	}
	
	@PostMapping("/register")
	public String registerTicket(@SessionAttribute("visitor") Visitor visitor ,@RequestParam("id") String id,  @RequestParam("fname") String fname, @RequestParam("lname") String lname, @RequestParam("age") String age) {
		
		// Need to generate ticket no
		visitor.setId(id);
		visitor.setFname(fname);
		visitor.setLname(lname);
		visitor.setAge(Integer.parseInt(age));
		
		
		
		visitor.setTicketno(service.getTicketNo(fname, lname, Integer.parseInt(age)));
		
		System.out.println("Visitor : "+visitor.getFname());
		
		return "redirect:/app/booking/summary";
		
	}
	
	@GetMapping("/summary")
	public String viewDetails(@SessionAttribute("visitor") Visitor visitor) {
		
		// Need to store in repository
		System.out.println("Ticket Summary : "+visitor.getId()+" : "+visitor.getFname()+":"+visitor.getLname()+":"+visitor.getAge()+":"+visitor.getTicketno());
		
		return "summary";
		
	}
	
	@PostMapping("/submit")
	public String submit(@SessionAttribute("visitor") Visitor visitor) {
		
		// Need to store in repository
		System.out.println("Ticket Summary : "+visitor.getFname()+":"+visitor.getLname()+":"+visitor.getAge()+":"+visitor.getTicketno());
		
		visitorService.saveVisitor(visitor);
		
		System.out.println("Ticket Summary : "+visitor.getFname()+":"+visitor.getLname()+":"+visitor.getAge()+":"+visitor.getTicketno());
		return "submit";
		
	}
	
	@GetMapping("/download")
	@ResponseBody
	public ResponseEntity<Resource> downloadTicket(@SessionAttribute("visitor") Visitor visitor , Locale locale, SessionStatus status ) {
		
		
	        String fileContent = visitor.getFname()+":"+visitor.getLname()+":"+visitor.getId()+":"+visitor.getAge()+":"+visitor.getTicketno();
	        byte[] fileData = fileContent.getBytes(StandardCharsets.UTF_8);
	        ByteArrayResource resource = new ByteArrayResource(fileData);

	        status.setComplete();
	        
	        
	        String filename = config.getMessage("filename", null, locale);
	        return ResponseEntity.ok()
	                // 1. Specify a known safe media type (like plain text or HTML)
	                .contentType(MediaType.TEXT_PLAIN) 
	                // 2. Explicitly ask the browser to display it inline
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename= "+filename)
	                .body(resource);
	}	
		
	}
	
	
	


