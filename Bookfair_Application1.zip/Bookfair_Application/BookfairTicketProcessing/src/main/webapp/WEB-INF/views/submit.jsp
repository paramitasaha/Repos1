
<!DOCTYPE html>
<html xmlns:th="http://thymeleaf.org">
<head>
    <title>Wizard - Step 2</title>
</head>
<body>
    <h2>Ticket Purchased</h2>
    <p>Details: ${visitor.fname}:${visitor.lname}:${visitor.id}:${visitor.ticketno}</p>
    <a href="http://localhost:8080/app/booking/download"> Download Ticket</a>
</body>
</html>
