<!DOCTYPE html>
<html>
<head>
    <title>Ticket Summary</title>
</head>
<body>
    <h2>Ticket Summary</h2>
       
    <form action="/app/booking/submit" method="post">
    	Visitor First Name = ${visitor.fname} <br>
    	Visitor Last Name  = ${visitor.lname} <br>
    	Visitor Age        = ${visitor.age} <br>
    	Visitor ID         = ${visitor.id} <br>
    	<button type="submit">Buy Ticket</button>  
    </form>

    
    
    
</body>
</html>
