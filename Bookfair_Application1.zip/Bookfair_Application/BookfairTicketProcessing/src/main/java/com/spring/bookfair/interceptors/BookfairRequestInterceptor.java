package com.spring.bookfair.interceptors;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.spring.bookfair.domain.Visitor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * An interceptor to log visitor ids who are accessing the Bookfair application.
 * 
 * 
 */


@Component

public class BookfairRequestInterceptor implements HandlerInterceptor {

	
   @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
     
	   
	   System.out.println("1.preHandle: Request intercepted before reaching controller. URL: " + request.getRequestURI());
	   
	   HttpSession session = request.getSession();
	   
	   Visitor visitor = (Visitor)session.getAttribute("visitor");
	   
	   
	   if(visitor == null) {
		   
		   
		   System.out.println("2.visitor "+ request.getParameter("id")+" invoked "+ request.getRequestURI());
	   }else {
		   
		   System.out.println("2.visitor "+ visitor.getId() +" invoked "+ request.getRequestURI());
 
	   }
	   
        // Return true to allow the request to proceed, false to block it
        return true; 
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println("2. postHandle: Executed after controller logic.");
        
        HttpSession session = request.getSession();
        
        Visitor visitor = (Visitor)session.getAttribute("visitor");
 	   
 	   
 	   if(visitor == null) {
 		   
 		   
 		   System.out.println("2.visitor "+ request.getParameter("id")+" invoked "+ request.getRequestURI());
 	   }else {
 		   
 		   System.out.println("2.visitor "+ visitor.getId() +" invoked "+ request.getRequestURI());
  
 	   }
        
        
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        System.out.println("3. afterCompletion: Request completely finished.");
    }
}
