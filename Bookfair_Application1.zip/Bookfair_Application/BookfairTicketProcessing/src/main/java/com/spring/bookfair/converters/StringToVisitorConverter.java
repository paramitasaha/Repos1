package com.spring.bookfair.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.spring.bookfair.domain.Visitor;
import com.spring.bookfair.exception.DataFormatException;

@Component
public class StringToVisitorConverter implements Converter<String, Visitor>{

	@Override
	public Visitor convert(String source) {
		
		
		String[] data = source.split("-");
		
		Visitor visitor = new Visitor();
		
		if(data.length< 3)
		{
			
			throw new DataFormatException();
		}
		
		visitor.setFname(data[0]);
		visitor.setLname(data[1]);
		visitor.setAge( Integer.parseInt(data[2]));
		visitor.setTicketno("No Ticket");
		
		// TODO Auto-generated method stub
		return visitor;
	}

}
