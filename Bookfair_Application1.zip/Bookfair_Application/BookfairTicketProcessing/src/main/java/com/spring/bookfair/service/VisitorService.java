package com.spring.bookfair.service;

import com.spring.bookfair.domain.Visitor;
/**
 * An interface to access Bookfair database
 * 
 * 
 */


public interface VisitorService {
	
	public void saveVisitor(Visitor visitor);
	public void createTable();
	
	
	
	

}
