package com.spring.bookfair.domain;

import org.springframework.stereotype.Component;
import org.springframework.web.service.annotation.HttpExchange;

import jakarta.persistence.Entity;

/**
 * Visitor pojo represents a visitor
 */

@Component
public class Visitor {
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	private String id ;
	
	private String fname;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getTicketno() {
		return ticketno;
	}
	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	private String lname;
	private String ticketno;
	private int age;

}
