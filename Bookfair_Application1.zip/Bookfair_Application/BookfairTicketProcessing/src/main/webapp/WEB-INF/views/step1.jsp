
<!DOCTYPE html>
<html>
<head>
    <title>Ticket Booking</title>
</head>
<body>
    <h2>Register Visitor</h2>
    
    <%-- The modelAttribute name must match the @SessionAttributes("preferences") string --%>
    <form action="/app/booking/register" method="post">
        <div>
          <input type="text" name="fname"><br>
          <input type="text" name="lname"><br>
          <input type="text" name="age"><br>
          <input type="text" name="id"><br>
        </div>
        <br/>
        <button type="submit">Register Visitor</button>
    </form>
</body>
</html>
