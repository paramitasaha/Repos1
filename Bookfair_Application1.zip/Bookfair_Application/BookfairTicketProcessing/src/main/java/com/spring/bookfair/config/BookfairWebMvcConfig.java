package com.spring.bookfair.config;

import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.annotation.Order;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.filter.ShallowEtagHeaderFilter;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.ApiVersionConfigurer;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.mvc.ParameterizableViewController;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
import org.springframework.web.servlet.view.BeanNameViewResolver;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.spring.bookfair.converters.StringToVisitorConverter;
import com.spring.bookfair.interceptors.BookfairRequestInterceptor;

import jakarta.persistence.EntityManagerFactory;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.spring.bookfair")
//@EnableJpaRepositories(basePackages = "com.spring.bookfair.repository")
public class BookfairWebMvcConfig implements WebMvcConfigurer {

	@Autowired
	BookfairRequestInterceptor interceptor;

	@Autowired
	StringToVisitorConverter converter;
	
	

	
	
	
	

	// Based on default version(Which can be overridden by API-Version request
	// header) appropriate version of mapped controller is invoked.......
	@Override
	public void configureApiVersioning(ApiVersionConfigurer configurer) {
		// 1. Choose how the version is resolved from the request
		configurer.useQueryParam("API-Version");
		// 2. Set the default fallback version if a client omits it
		configurer.setDefaultVersion("1.0");

		// @GetMapping version is 1.0+ means for version 1.0 and all supported version
		// above 1.0 requests will be answered
		// 3. Declare which versions your application officially supports
		configurer.addSupportedVersions("1.0", "1.2", "1.3");
	}
	
	
	@Bean
    public DataSource dataSource() {
        // Creates an in-memory H2 database instance automatically
		
		 DriverManagerDataSource dataSource = new DriverManagerDataSource();
	        dataSource.setDriverClassName("org.h2.Driver");
	        dataSource.setUrl("jdbc:h2:~/test;DB_CLOSE_DELAY=-1");
	        dataSource.setUsername("sa");
	        dataSource.setPassword("");
        
        return dataSource;
		
		/*
        return new EmbeddedDatabaseBuilder()
                .setType(EmbeddedDatabaseType.H2)
                .setName("visitordb") // Equates to jdbc:h2:mem:testdb
                .addScript("classpath:schema.sql") // Optional initial schema
                   // Optional initial data
                .build();
    */}

	@Bean
    public NamedParameterJdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }
	
	@Bean
	public ViewResolver viewResolver() {

		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();

		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");

		return viewResolver;

	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		// TODO Auto-generated method stub
		registry.addInterceptor(interceptor).addPathPatterns("/booking/**");
		registry.addInterceptor(localeChangeInterceptor()).addPathPatterns("/booking/**");

		System.out.println("interceptor invoked.......");

	}

	@Bean
	public LocaleResolver localeResolver() {
		SessionLocaleResolver slr = new SessionLocaleResolver();
		slr.setDefaultLocale(Locale.US); // Set default language
		return slr;
	}

	// 2. Define the Interceptor to watch for a query parameter
	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor() {
		LocaleChangeInterceptor lci = new LocaleChangeInterceptor();
		lci.setIgnoreInvalidLocale(false);

		lci.setParamName("lang"); // URL parameter name to trigger language change (e.g., ?lang=fr)
		System.out.println("local change interceptor created");
		return lci;
	}

	@Bean

	public MessageSource messageSource() {

		ResourceBundleMessageSource msgSrc = new ResourceBundleMessageSource();

		msgSrc.setBasename("Config");

		return msgSrc;

	}

	@Bean
	public MultipartResolver multipartResolver() {

		StandardServletMultipartResolver resolver = new StandardServletMultipartResolver();
		return resolver;

	}

	@Override
	public void addFormatters(FormatterRegistry registry) {

		registry.addConverter(converter);
	}

}
