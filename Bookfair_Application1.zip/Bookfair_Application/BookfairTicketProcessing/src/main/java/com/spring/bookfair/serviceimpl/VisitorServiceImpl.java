package com.spring.bookfair.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.spring.bookfair.domain.Visitor;
import com.spring.bookfair.repository.VisitorRepository;
import com.spring.bookfair.service.VisitorService;

/**
 * Generic Service to access DB.
 * 
 * 
 */




@Service
public class VisitorServiceImpl implements VisitorService{

	private String sql_create =  // 3. Create a table
	        "CREATE TABLE IF NOT EXISTS visitors (" +
                    "id VARCHAR(100) PRIMARY KEY , " +
                    "fname VARCHAR(100), " +
                    "lname VARCHAR(100),"+
                    "ticketno VARCHAR(100),"+
                    "age INT )";
	
	private String sql_insert = "INSERT INTO visitors (id, fname, lname,ticketno,age) VALUES (:id, :fname, :lname,:ticketno,:age)";

	
	
	@Autowired
	NamedParameterJdbcTemplate jdbctemplate;
	//@Autowired
	//private VisitorRepository visitorRepository;
	
	@Override
	public void saveVisitor(Visitor visitor) {
		
		System.out.println("Visitor about to save "+visitor);
		// TODO Auto-generated method stub
		
		BeanPropertySqlParameterSource data = new BeanPropertySqlParameterSource(visitor);
		
		int count  = jdbctemplate.update(sql_insert, data);
		
		if(count > 0) {		
			System.out.println("visitor successfully saved "+visitor);
		}else {
			
			System.out.println("visitor not successfully saved");
		}
	}

	@Override
	public void createTable() {
		// TODO Auto-generated method stub
		jdbctemplate.getJdbcOperations().execute(sql_create);
	}

}
