package com.spring.bookfair.service;

import java.util.Random;

import org.springframework.stereotype.Service;
import org.springframework.web.service.annotation.HttpExchange;

import com.spring.bookfair.domain.Visitor;

/**
 * 
 * An interface holding generic methods to access Bookfair application
 */

public interface BookfairService {
	
	public String getTicketNo(String fname , String lname, int age);
	
	
	
	
	
}
