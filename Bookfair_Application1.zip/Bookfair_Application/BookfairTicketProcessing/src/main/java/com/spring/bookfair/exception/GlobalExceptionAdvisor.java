package com.spring.bookfair.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * A generic exception handler for Bookfair application
 * 
 */

@ControllerAdvice
public class GlobalExceptionAdvisor {
	
	@ExceptionHandler({Exception.class})
	public ResponseEntity<String> handleIOException(Exception ex) {
		return ResponseEntity.internalServerError().body("Below Listed Exception Caught: \\n "+ex.getMessage());
	}
	

}
