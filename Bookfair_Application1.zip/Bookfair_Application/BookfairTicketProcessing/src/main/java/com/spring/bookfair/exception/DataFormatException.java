package com.spring.bookfair.exception;

public class DataFormatException extends RuntimeException {
	
	


}
