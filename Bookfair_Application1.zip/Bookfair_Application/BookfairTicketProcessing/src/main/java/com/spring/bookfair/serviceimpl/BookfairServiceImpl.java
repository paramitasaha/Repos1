package com.spring.bookfair.serviceimpl;

import java.util.Random;

import org.springframework.stereotype.Service;

import com.spring.bookfair.service.BookfairService;

/**
 * An implementation of generic services offered by Bookfair app.
 * 
 */


@Service("bookfairService")
public class BookfairServiceImpl implements BookfairService{

	@Override
	public String getTicketNo(String fname, String lname, int age) {
	
				
				Random random = new Random();
				
				String ticketno = fname.substring(0,1).concat(lname.substring(0, 1)).concat(""+random.nextLong());
				
				return ticketno;
				
		
	}

}
